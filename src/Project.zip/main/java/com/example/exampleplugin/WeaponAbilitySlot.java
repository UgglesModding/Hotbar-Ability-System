package com.example.exampleplugin;

public class WeaponAbilitySlot {
    public String Key;          // Ability_DaggerLeap
    public String RootInteraction;         // Root_Ability_DaggerLeap
    public int MaxUses;
    public float PowerMultiplier;
}
