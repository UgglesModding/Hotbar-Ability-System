package com.example.exampleplugin;

import java.util.List;

public class WeaponIndex {
    // This matches your index.json structure:
    // { "Weapons": [ "Server/Item/Items/Weapons/CAO_Weapons/CAO_Weapon.json", ... ] }
    public List<String> Weapons;
}
