package com.example.exampleplugin;

import java.util.List;

public class AbilityIndex {
    public List<String> abilities;
}
